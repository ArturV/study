// const myName = "Andrius"

// const nameLenght = myName.length < 5 ? "Short name" : "Long name";
// console.log(nameLenght);

// const clientAge = 17;
// const legalAge = 18;

// const driveable = clientAge >= legalAge ? "Can drive" : "Can't drive";
// console.log(driveable);

// const clientAge = 120;
// const legalAge = 18;

// const driveable = clientAge <= 0 || clientAge >= 120 ? "Invalid Age" : (clientAge >= legalAge ? "Can drive" : "Can't drive");
// console.log(driveable);

const phone = "iPhone";
const isIphoneUser = phone === "iPhone";
console.log(isIphoneUser);