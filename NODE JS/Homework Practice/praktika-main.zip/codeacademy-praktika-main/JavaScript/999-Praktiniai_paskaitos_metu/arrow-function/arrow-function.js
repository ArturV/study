function showAlert() {
  alert("message");
}

showAlert();

const showPrompt = () => {
  prompt();
};

showPrompt();

const getMultipliedByTwo = (value) => value * 2;

console.log(getMultipliedByTwo(10));
