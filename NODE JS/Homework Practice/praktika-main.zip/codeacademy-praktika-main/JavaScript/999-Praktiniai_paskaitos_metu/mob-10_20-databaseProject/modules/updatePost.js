const updatePost = async () => {
  const newBodyValue = document.querySelector("#newBodyInput").value.trim();

  console.log(newBodyValue);
};

export { updatePost };
