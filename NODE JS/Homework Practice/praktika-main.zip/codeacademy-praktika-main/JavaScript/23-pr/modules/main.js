import { populateTable } from "./populateTable.js";

await populateTable();
