// const legalAge = 20;
// const clientAge = 10;

// if (legalAge <= clientAge) {
//     alert("pilnametis")
// }
// else {
//     alert("nepilnametis")
// }

// const clientName = "Andrius";

// if (clientName.length >= 6) {
//     alert("ilgas vardas")
// }

// const myAge = prompt("Koks tavo amzius");

// if (myAge > 100 || myAge < 0) {
//     alert("invalid age")
// }
// else if (myAge >= 1 && myAge <= 18) {
//     alert("child")
// }
// else if (myAge >= 19 && myAge <= 99) {
//     alert("Adult")
// }
// else {
//     alert("neteisinga reiksme")
// }

const car = prompt("Masina");

if (car === "Audi" || car === "VW" || car === "Bentley" || car === "Bugatti" || car === "Lamborghini" || car === "Porsche") {
    alert("VW group")
}
else if (car === "BMW" || car === "Mini" || car === "Rolls - Royce") {
    alert("BMW group")
}
else {
    alert("Nepriklauso grupei")
}