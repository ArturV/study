const computerName = "Apple MacBook Pro";
const year = 2019;

console.log(`${computerName} ${year}`);
