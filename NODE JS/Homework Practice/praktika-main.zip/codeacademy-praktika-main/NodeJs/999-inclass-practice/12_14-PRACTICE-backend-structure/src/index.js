require("dotenv").config();
require("./getShirts").getShirts();
