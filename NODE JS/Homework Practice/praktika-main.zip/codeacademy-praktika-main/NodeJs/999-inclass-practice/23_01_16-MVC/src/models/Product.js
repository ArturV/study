export class Product {
  price;
  title;
  isAvailable;

  constructor(price, title, isAvailable) {
    this.price = price;
    this.title = title;
    this.isAvailable = isAvailable;
  }
}
