export { Products } from "./Products";

export const PRODUCTS_CACHE_LS_NAME = "productsData";
