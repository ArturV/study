export const NotFoundPage = () => {
  return <h1>Page does not exist</h1>;
};
